﻿using MelonLoader;
using AMod;
[assembly: MelonInfo(typeof(AMod.AMod), "AMod", "2.2", "Airbronze")]
[assembly: MelonGame("Kukouri", "Pixel Worlds")]