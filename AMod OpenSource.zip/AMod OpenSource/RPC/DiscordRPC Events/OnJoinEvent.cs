﻿using System;
using DiscordRPC.Message;

namespace DiscordRPC.Events
{
    public delegate void OnJoinEvent(object sender, JoinMessage args);
}
