﻿using System;
using DiscordRPC.Message;

namespace DiscordRPC.Events
{
    public delegate void OnCloseEvent(object sender, CloseMessage args);
}
