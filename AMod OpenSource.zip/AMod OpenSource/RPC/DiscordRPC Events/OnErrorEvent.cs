﻿using System;
using DiscordRPC.Message;

namespace DiscordRPC.Events
{
    public delegate void OnErrorEvent(object sender, ErrorMessage args);
}
