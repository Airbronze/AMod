﻿using System;
using DiscordRPC.Message;

namespace DiscordRPC.Events
{
    public delegate void OnSpectateEvent(object sender, SpectateMessage args);
}
