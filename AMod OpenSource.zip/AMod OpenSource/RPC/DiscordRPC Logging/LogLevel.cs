﻿using System;

namespace DiscordRPC.Logging
{
    public enum LogLevel
    {
        Trace = 1,
        Info,
        Warning,
        Error,
        None = 256
    }
}
