﻿using System;

namespace DiscordRPC.RPC
{
    internal enum RpcState
    {
        Disconnected,
        Connecting,
        Connected
    }
}
